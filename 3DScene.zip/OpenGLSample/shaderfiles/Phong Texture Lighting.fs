in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform or Global variables for object color, light color, light position, and camera/view position
//uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightColor2;
uniform vec3 lightPos;
uniform vec3 lightPos2;
uniform vec3 viewPosition;

in vec2 TexCoord;

// texture sampler
uniform sampler2D texture1;

//void main()
//{
	//FragColor = texture(texture1, TexCoord);
//}

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or global lighting strength.
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color.

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit.
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube.
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light.
    vec3 diffuse = impact * lightColor; // Generate diffuse light color.

    vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube.
    float impact2 = max(dot(norm, lightDirection2), 0.0);// Calculate diffuse impact by generating dot product of normal and light.
    vec3 diffuse2 = impact2 * lightColor2; // Generate diffuse light color.


    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength.
    float highlightSize = 16.0f; // Set specular highlight size.
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction.
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector.
    vec3 reflectDir2 = reflect(-lightDirection2, norm);// Calculate reflection vector.


    //Calculate specular component.
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;
    vec3 specular2 = specularIntensity * specularComponent2 * lightColor2;

    vec3 objectColor = texture(texture1, TexCoord).rgb;

    // Calculate Phong result.
    vec3 phong = (ambient + diffuse + specular + diffuse2 + specular2) * objectColor;

    fragmentColor = vec4(phong, 1.0f); // Send lighting results to GPU.


}